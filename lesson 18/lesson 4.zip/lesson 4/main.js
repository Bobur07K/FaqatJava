// alert('Habar');
// console.log('Manashunaqa qilib');
// document.write('<h1>Hello World</h1><h1>Hello World</h1>');

// console.log(prompt());

// let a = 'Hello World';

// console.log(a);

// let ketmon = prompt();

// console.log(ketmon);


// let bolta = 12;
// var a = 13;
// const b = 14;

// b = 18;
// console.log(b);

// bolta = 13;

// console.log(bolta);

// a = 15;

// console.log(a)


// let a = 12,
//     b = 13,
//     c = 14,
//     d = 15,
//     e = "Hello World",
//     hullas = true,
//     nohullas = false;

// let tip = typeof(hullas);

// console.log(tip);

    // console.log(typeof(hullas));



// let ism = prompt('Nimadir kiritta');

// document.write('<h1>' + ism  + '</h1>');

// let bet = prompt();


// let ism = prompt('Ismingizni kiriting');

// document.getElementById('misol').innerHTML += ism;


function btn() {
    let ism = prompt('ism kiriting');
    document.getElementById('ul').innerHTML += '<li>' + ism + '</li>'
}

